export const categories = [
  { id: "teclados", name: "Teclados", emoji: "⌨️" },
  { id: "mouse", name: "Mouse", emoji: "🖱️" },
  { id: "audio", name: "Audio", emoji: "🎧" },
  { id: "monitores", name: "Monitores", emoji: "🖥️" },
  { id: "accesorios", name: "Accesorios", emoji: "🔌" },
  { id: "ofertas", name: "Ofertas", emoji: "🔥" },
];
