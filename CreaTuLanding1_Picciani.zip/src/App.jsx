import "./App.css";
import NavBar from "./components/NavBar/NavBar";
import ItemListContainer from "./components/ItemListContainer/ItemListContainer";

function App() {
  return (
    <div>
      <NavBar />
      <ItemListContainer greeting="¡Bienvenido/a a PeriStore! Encontrá tus periféricos ideales 🖥️" />
    </div>
  );
}

export default App;
