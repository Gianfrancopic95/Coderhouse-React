
import "./ItemListContainer.css";

const ItemListContainer = ({ greeting }) => {
  const categorias = [
    { id: "teclados", nombre: "Teclados", emoji: "⌨️" },
    { id: "mouse", nombre: "Mouse", emoji: "🖱️" },
    { id: "audio", nombre: "Audio", emoji: "🎧" },
    { id: "monitores", nombre: "Monitores", emoji: "🖥️" },
    { id: "accesorios", nombre: "Accesorios", emoji: "🔌" },
    { id: "ofertas", nombre: "Ofertas", emoji: "🔥" },
  ];

  return (
    <main className="ilc">
      <h2 className="ilc__title">{greeting}</h2>

      <section className="ilc__section">
        <h3 className="ilc__subtitle">Categorías</h3>

        <div className="ilc__grid">
          {categorias.map((cat) => (
            <article key={cat.id} className="ilc__card">
              <span className="ilc__emoji">{cat.emoji}</span>
              <h4 className="ilc__cardTitle">{cat.nombre}</h4>
              <button className="ilc__btn">
                Ver {cat.nombre}
              </button>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
};

export default ItemListContainer;
