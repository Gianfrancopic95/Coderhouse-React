import "./NavBar.css";
import CartWidget from "../CartWidget/CartWidget";

const NavBar = () => {
  return (
    <header className="navHeader">
      <nav className="navBar">
        <a className="brand" href="#inicio" aria-label="Ir al inicio">
          <span className="logo" aria-hidden="true">🖥️</span>
          <span className="brandName">PeriStore</span>
          <span className="brandTagline">Periféricos para gaming y oficina</span>
        </a>

        <ul className="navLinks" aria-label="Navegación principal">
          <li><a href="#teclados">Teclados</a></li>
          <li><a href="#mouse">Mouse</a></li>
          <li><a href="#audio">Audio</a></li>
          <li><a href="#monitores">Monitores</a></li>
          <li><a href="#ofertas">Ofertas</a></li>
        </ul>

        <CartWidget />
      </nav>
    </header>
  );
};

export default NavBar;
