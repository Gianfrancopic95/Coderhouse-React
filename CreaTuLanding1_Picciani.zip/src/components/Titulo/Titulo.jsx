const Titulo = () => {

    const styles = {
        backgroundColor: "darkCyan",
        color: "white",
        padding: "20px",
        borderradius: "10px"
    };

    return(
        <h2 style={styles} >bienvenido al curso de react</h2>
    )
}

export default Titulo;